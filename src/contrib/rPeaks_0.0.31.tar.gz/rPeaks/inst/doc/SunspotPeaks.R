## -----------------------------------------------------------------------------
library(datasets)
library(rPeaks)
library(stats)
library(graphics)

## -----------------------------------------------------------------------------
smf <- abs(fft(spec.taper(as.vector(sunspot.month),p=0.5)))

## -----------------------------------------------------------------------------
smb <- SpectrumBackground(smf,iterations=100)

## -----------------------------------------------------------------------------
z <- SpectrumSearch(smf-smb)

## ---- fig.width=7, fig.height=4-----------------------------------------------
plot(smf-smb,type="l",xlim=c(0,200))
lines(z$y,type="l",col="red")
points(y=rep(-10,length(z$pos)),x=z$pos,col="green",pch="+",cex=2)
text(100, 25000, paste(length(z$pos)/2," harmonics were found with ",
            z$pos[1],"-month base period",sep=""))

